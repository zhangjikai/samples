var example = new COREHTML5.polygonExample();

example.polygonsTransparencySlider.appendTo('polygons-transparency-slider');
example.polygonsTransparencySlider.draw();
