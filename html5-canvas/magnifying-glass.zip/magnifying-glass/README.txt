This is the magnifying glass application from the Mobile chapter of Core HTML5 Canvas. You can save the application to your home screen on an iPad, and when you click the icon, the application will run in full-screen mode, indistinguishable from a native iOS application. See the mobile chapter of Core HTML5 Canvas for more details.

See LICENSE.txt for restrictions on the use of this code.
